//
//  Enemy.swift
//  ARAPIStarter
//
//  Created by Briana Jones on 11/18/23.
//  Copyright © 2023 Line Break, LLC. All rights reserved.
//

import Foundation
import ARKit
import RealityKit

class Enemy: Entity {
    private var timer: Timer?
    private var cameraView: ARView?
    private var currentPosition: SIMD3<Float>?
    private var playerPosition: SIMD3<Float>?
    private var health: Float = 100
    private var attackDmg: Int?
    private var element : String?
    private var movementSpeed: Float = 0.1
    private var isColliding: Bool = false
    private var dmg: Float = 0.0
    
//    private var onFrameUpdate: (() -> Void)?

    var active: Bool = true {
        didSet {
            // physics
            if active {
            } else {
                self.model?.isEnabled = false
                print("didSet", active)
            }
        }
    }

    var model: ModelEntity? {
        didSet {
            if let model = self.model {
                // Set the model entity's initial properties
                model.scale = [1.0, 1.0, 1.0]
                //model.generateCollisionShapes(recursive: true)
                model.isEnabled = active // Enable the model if 'active' is true
            }
        }
    }
    
    var trackModel: HomeTower?

    init(modelEntity: ModelEntity, status: Bool, cameraView: ARView, name: String, type: String, homeEntity: HomeTower) {
        super.init()
        self.active = status
        self.element = type
        self.model = modelEntity
        self.model?.name = name
        self.trackModel = homeEntity
        
        if let model = self.model {
            self.addChild(model)
        }

        self.cameraView = cameraView

        //Start a timer to update the position at random intervals
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.updatePosition()
            self?.checkHealth()
        }
        
//        cameraView.scene.subscribe(
//                to: SceneEvents.Update.self,
//                on: self
//            ) { [weak self] event in
//            self?.updatePerFrame()
//        }
    }

    @MainActor required init() {
        fatalError("init() has not been implemented")
    }

    deinit {
        timer?.invalidate()
    }
    
//    func setDmg(multi: Float){
//        dmg = multi
//    }
    
    func createDmg(multi: Float){
        let time = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.minusHealth(multi: multi)
        }
    }
    
    func minusHealth(multi: Float){
        if(isColliding){
            health -= 5.0*multi
        }
        print("health: ", health)
    }
    
    func minusSpecial(multi: Float){
        if(isColliding){
            health -= 20.0*multi
        }
        print("health: ", health)
    }
    
    func changeStateTrue(){
        isColliding = true
    }
    
    func changeStateFalse(){
        isColliding = false
    }
    
    func checkHealth(){
        if(health <= 0){
            removeFromParent()
            print("dead")
            //active = false
            return
        }
        
        //print("health: ", health)
    }
    
    func getElement() -> String{
        return element!
    }
    
    func updatePosition() {
            guard trackModel != nil, self.position != nil else {
                return
            }

            // Now you can safely use trackModel and self.position without optional binding
            let playerPosition = trackModel!.position
            let currentPosition = self.position


            // Calculate the direction from the current position to the player's position
            let direction = simd_normalize(playerPosition - currentPosition)

            // Calculate the new position using smoothstep for smooth movement
            let newPosition = currentPosition + direction * movementSpeed

            // Update the position of the enemy
            self.position = newPosition
        
            
    }
    
//    func updatePerFrame(){
//        if(health <= 0){
//            removeFromParent()
//            print("dead")
//            //active = false
//            return
//        }
//        
//        updatePosition()
//        
//        if(isColliding){
//            timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
//                self?.minusHealth(multi: self?.dmg!)
//            }
//            //minusHealth(multi: dmg)
//        }
//        else{
//            timer?.invalidate()
//        }
//    }
}
