//
//  ContentView.swift
//  ARAPIStarter
//
//  Created by Nien Lam on 10/19/23.
//  Copyright © 2023 Line Break, LLC. All rights reserved.
//

import SwiftUI
import RealityKit

struct ContentView: View {
    @State var viewModel: ViewModel

    var body: some View {
        ZStack {
            // AR View.
            ARViewContainer(viewModel: viewModel)
//                .gesture(TapGesture().onEnded {
//                    // Handle tap gesture here
//                    print("Tap gesture detected")
//                })
//                .gesture(DragGesture().onChanged { value in
//                    // Handle drag gesture here
//                    print("Drag gesture detected: \(value.translation)")
//                })
            
            // Reset button.
            Button {
                viewModel.uiSignal.send(.reset)
            } label: {
                Label("Reset", systemImage: "gobackward")
                    .font(.system(.title))
                    .foregroundColor(.white)
                    .labelStyle(IconOnlyLabelStyle())
                    .frame(width: 44, height: 44)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            
            .padding()
        
            HStack{
                Button("Spawn Player") {
                    viewModel.uiSignal.send(.spawnPlayer)
                }
                Button("Spawn Enemy") {
                    viewModel.uiSignal.send(.spawnEnemy)
                }
                Button("Spawn Tower") {
                    viewModel.uiSignal.send(.spawnTower)
                }
                Button("Special Attack") {
                    viewModel.uiSignal.send(.specialAttack)
                }
            }
        }
    }
}

#Preview {
    ContentView(viewModel: ViewModel())
}
