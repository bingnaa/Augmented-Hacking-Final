//
//  ARView.swift
//  ARAPIStarter
//
//  Created by Nien Lam on 10/19/23.
//  Copyright © 2023 Line Break, LLC. All rights reserved.
//

//need to do: drag player, tower
//special attcks (do one type)

import SwiftUI
import ARKit
import RealityKit
import Combine

struct ARViewContainer: UIViewRepresentable {
    let viewModel: ViewModel
    
    func makeUIView(context: Context) -> SimpleARView {
        SimpleARView(frame: .zero, viewModel: viewModel)
    }
    
    func updateUIView(_ arView: SimpleARView, context: Context) { }
}

class SimpleARView: ARView {
    var viewModel: ViewModel
    var arView: ARView { return self }
    var subscriptions = Set<AnyCancellable>()

    var originAnchor: AnchorEntity!
    var pov: AnchorEntity!

    //var sphere: ModelEntity!
    var playerObject: Player!
    var myTowerEntity: Tower!
    var hCard: HomeTower!
    var playerAttackArea: AreaOfAttack!
    
    //towers
    var fireTowerEntity: Tower!
    var grassTowerEntity: Tower!
    var waterTowerEntity: Tower!
    
    var tapGesture: UITapGestureRecognizer?
    var longGesture: UILongPressGestureRecognizer?
    
    init(frame: CGRect, viewModel: ViewModel) {
        self.viewModel = viewModel
        super.init(frame: frame)
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    required init(frame frameRect: CGRect) {
        fatalError("init(frame:) has not been implemented")
    }
    
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        
        UIApplication.shared.isIdleTimerDisabled = true
        
        setupScene()
        //setupEntities()
        setupSubscriptions()
    }
        
    func setupScene() {
        //self.isUserInteractionEnabled = true
        
        // Create an anchor at scene origin.
        originAnchor?.removeFromParent()
        originAnchor = nil
        originAnchor = AnchorEntity(plane: [.horizontal])
        originAnchor?.orientation = simd_quatf(angle: .pi / 2, axis: [0,1,0])
        arView.scene.addAnchor(originAnchor)
        
        // Add pov entity that follows the camera.
        pov = AnchorEntity(.camera)
        arView.scene.addAnchor(pov)
        
        // Setup world tracking and plane detection.
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        configuration.environmentTexturing = .automatic
        arView.renderOptions = [.disableDepthOfField, .disableMotionBlur]

        //don't have sceneReconstruction
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            configuration.sceneReconstruction = .mesh
        } else {
            print("❗️ARWorldTrackingConfiguration: Does not support sceneReconstruction.")
        }

        arView.session.run(configuration)

        // DEBUG
        arView.environment.sceneUnderstanding.options.insert(.physics)
        arView.debugOptions.insert(.showSceneUnderstanding)
        //  arView.debugOptions.insert(.showPhysics)
        
//        if let tapGesture = tapGesture {
//            self.addGestureRecognizer(tapGesture)
//            self.installGestures([.translation, .rotation], for: playerObject as! HasCollision)
//        } else {
//            // Handle the case where tapGesture is nil
//            print("tapGesture is nil")
//        }
        
        //panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        arView.addGestureRecognizer(tapGesture!)
        
        //self.installGestures([.rotation, .translation, .scale], for: playerObject as! HasCollision)
                
        longGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongPress(_:)))
        self.addGestureRecognizer(longGesture!)
    }

    func setupSubscriptions() {
        // Process UI signals.
        viewModel.uiSignal.sink { [weak self] in
            self?.processUISignal($0)
        }
        .store(in: &subscriptions)
        
        arView.debugOptions = [.showPhysics]
        
        // Respond to collision events 💥.
        arView.scene.subscribe(to: CollisionEvents.Began.self) { [weak self] event in
            guard let self else { return }
            
            //If entity with name obstacle1 collides with anything.
            if event.entityA.name == "PlayerAOA" || event.entityB.name == "EnemyAOA" {
                
                // TODO: Add logic for collision.
                //print("COLLISION- attackarea")
                
                if let myEnemy = event.entityB.parent?.parent?.parent as? Enemy {
                    //print("dupe")
                    myEnemy.changeStateTrue()
                    let enemyElement = myEnemy.getElement()
                    myEnemy.createDmg(multi: attackMultiplier(attackType: "fire", enemyType: enemyElement))
                } else {
                    //prints "Slime"
                    //print(event.entityB.parent?.parent)
                    //prints Enemy
                    //print(event.entityB.parent?.parent?.parent)
                    print("Cast failed")
                }
            }
            else if event.entityA.name == "home" || event.entityB.name == "EnemyAOA" {

                if let myHome = event.entityA.parent?.parent as? HomeTower {
                    //print("dupe")
                    //myHome.
                } else {
                    //prints "Slime"
                    //print(event.entityB.parent?.parent)
                    //prints Enemy
                    //print(event.entityB.parent?.parent?.parent)
                    print("Cast failed")
                }
                
                print("COLLISION- home")
            }
        }.store(in: &subscriptions)
        
        arView.scene.subscribe(to: CollisionEvents.Ended.self) { [weak self] event in
            guard let self else { return }
            
            //If entity with name obstacle1 collides with anything.
            if event.entityA.name == "PlayerAOA" || event.entityB.name == "EnemyAOA" {
                if let myEnemy = event.entityB.parent?.parent?.parent as? Enemy {
                    print("dupe")
                    myEnemy.changeStateFalse()
                } else {
                    print("Cast failed")
                }
            }
        }.store(in: &subscriptions)
    }
    
    func processUISignal(_ signal: ViewModel.UISignal) {
        switch signal {
        case .reset:
            resetScene()
        case .spawnEnemy:
            spawnSlimes()
        case .spawnPlayer:
            spawnPlayer()
        case .specialAttack:
            triggerSpecial()
        case .spawnTower:
            spawnTower()
        }
    }
    
    // Define entities here.
    func setupEntities() {
    }
    

    // Reset scene.
    func resetScene() {
        originAnchor?.removeFromParent()
        //originAnchor = nil
        originAnchor = AnchorEntity(plane: [.horizontal])
        originAnchor?.orientation = simd_quatf(angle: .pi / 2, axis: [0,1,0])
        arView.scene.addAnchor(originAnchor!)
    }
    
    func attackMultiplier (attackType: String, enemyType: String) -> Float{
        print("attackType:", attackType, " enemyType: ", enemyType)
        if(attackType == "water" && enemyType == "fire"){
            return 2.0
        }
        else if(attackType == "fire" && enemyType == "grass"){
            return 2.0
        }
        else if(attackType == "grass" && enemyType == "water"){
            return 2.0
        }
        else if(attackType == "fire" && enemyType == "water"){
            return 0.5
        }
        else if(attackType == "water" && enemyType == "grass"){
            return 0.5
        }
        else if(attackType == "grass" && enemyType == "fire"){
            return 0.5
        }
        else {
            // Handle same type attacks
            return 1.0
        }
    }
    
    func spawnSlimes(){
        let randomVal = Float.random(in: -2.0 ... -0.2)
        print(randomVal)
        
        let slimeMesh = MeshResource.generateSphere(radius: 0.1)
        let slimeMaterial = SimpleMaterial(color: .green, isMetallic: false)
        let sEntity = ModelEntity(mesh: slimeMesh, materials: [slimeMaterial])
        
        // Add child plane for area of attack (collision detection)
        let cMesh = MeshResource.generatePlane(width: 0.5, depth: 0.5, cornerRadius: 0.5)
        //let cMesh = MeshResource.generateBox(size: [0.5, 0.5, 0.5], cornerRadius: 0.2)
        let cMaterial = SimpleMaterial(color: UIColor.white.withAlphaComponent(0.2), isMetallic: false)
        let aoaEntity = ModelEntity(mesh: cMesh, materials: [cMaterial])
        aoaEntity.generateCollisionShapes(recursive: true)
        
        let attackArea = AreaOfAttack(modelEntity: aoaEntity, name: "EnemyAOA")

        //aoaEntity.position = [0, 0, 0]
        sEntity.addChild(attackArea)
        aoaEntity.position = [0, -0.1, 0]
        
        let arSlime = Enemy(modelEntity: sEntity, status: true, cameraView: arView, name: "Slime", type: "fire", homeEntity: hCard)
        originAnchor.addChild(arSlime)
        arSlime.transform.matrix = pov.transformMatrix(relativeTo: originAnchor) * float4x4(translation: [randomVal, 0.0, randomVal])
    }
    
    func spawnPlayer(){
        let homeCard = MeshResource.generatePlane(width: 0.2, height: 0.1)
        let homeCardMaterial = SimpleMaterial(color: .green, isMetallic: false)
        let hCardEntity = ModelEntity(mesh: homeCard, materials: [homeCardMaterial])
        hCardEntity.generateCollisionShapes(recursive: true)

        hCard = HomeTower(modelEntity: hCardEntity, status: true, cameraView: arView, name: "home")
        
        let mesh = MeshResource.generateSphere(radius: 0.1)
        let material = SimpleMaterial(color: .red, isMetallic: false)
        let mEntity = ModelEntity(mesh: mesh, materials: [material])
        mEntity.generateCollisionShapes(recursive: true)
        
        // Add child plane for area of attack (collision detection)
        let cMesh = MeshResource.generatePlane(width: 0.5, depth: 0.5, cornerRadius: 0.5)
        //let cMesh = MeshResource.generateBox(size: [0.5, 0.5, 0.5], cornerRadius: 0.2)
        let cMaterial = SimpleMaterial(color: UIColor.white.withAlphaComponent(0.2), isMetallic: false)
        let aoaEntity = ModelEntity(mesh: cMesh, materials: [cMaterial])
        aoaEntity.generateCollisionShapes(recursive: true)
        
        playerAttackArea = AreaOfAttack(modelEntity: aoaEntity, name: "PlayerAOA")

        //aoaEntity.position = [0, 0, 0]
        mEntity.addChild(playerAttackArea)
        aoaEntity.position = [0, -0.1, 0]
        
        hCardEntity.position = [0, -0.1, 0]

        playerObject = Player(modelEntity: mEntity, cameraView: arView, name: "Player")
        playerObject.transform.matrix = pov.transformMatrix(relativeTo: originAnchor) * float4x4(translation: [0.0, 0.0, -0.5])
        //let arObject = SphereEntity(name: "sphere", radius: 0.1, imageName: "checker.png")
        originAnchor.addChild(playerObject)
        playerObject.position = [0, 0, 0]
        
        if let longG = longGesture {
            self.addGestureRecognizer(longG)
            self.installGestures([.translation], for: playerObject as! HasCollision)
        } else {
            // Handle the case where tapGesture is nil
            print("longG is nil")
        }
    }
    
    func triggerSpecial(){
        //print(playerObject.children)
        print(playerObject.children[0].children[0])
        if let area = playerObject.children[0].children[0] as? AreaOfAttack {
            print("dupe")
            area.changeScaleBig()
        } else {
            print("Cast failed")
        }
    }
    
    func spawnTower(){
        let cardMesh = MeshResource.generatePlane(width: 0.2, height: 0.1)
        let cardMaterial = SimpleMaterial(color: .green, isMetallic: false)
        let cardEntity = ModelEntity(mesh: cardMesh, materials: [cardMaterial])
        
        cardEntity.generateCollisionShapes(recursive: true)
        
        myTowerEntity = Tower(modelEntity: cardEntity, status: true, cameraView: arView, name: "Tower", type: "fire")
                
        // Add the card entity to the scene
        originAnchor.addChild(cardEntity)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        //        if let playerCollision = playerObject as? HasCollision {
        //            print("woo")
        //            self.installGestures([.translation], for: playerCollision)
        //            print("hasCollision: Player")
        //        }
        
        if sender.state == .ended {
            print("handletap ended")
            let tapLocation = sender.location(in: arView)
            
            //guard let hitEntity = self.entity(at: tapLocation) else { return }
            guard let hitEntity = self.entity(at: tapLocation) else {
                print("No entity found at the tapped location")
                return
            }
            
            if !hitEntity.name.isEmpty {
                let entityName = hitEntity.name
                print("TOUCHING ENTITY NAMED:", entityName)
            } else {
                print("Found entity, but it has no name")
                return
            }
            
            print("TOUCHING ENTITY NAMED:", hitEntity.name)
            
        }
    }
    
    @objc func handleLongPress(_ recognizer: UITapGestureRecognizer? = nil) {
        print("long press")

        guard let touchInView = recognizer?.location(in: self) else {
            return
        }

        guard let modelEntity = self.entity(at: touchInView) as? ModelEntity else {
            print("modelEntity not found")
            return
        }
        
        print("Long press detected on - \(modelEntity.name)")
            
    }
    
}
